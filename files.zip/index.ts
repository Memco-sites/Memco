// Supabase Edge Function: memco-users
// Creates / updates / deletes login accounts on the server, so no
// password or secret key ever sits in index.html.
//
// Actions:
//   register     – anyone: HR Number + correct name + password (self-registration)
//   create_user  – Super Admin only
//   update_login – Super Admin only (new password and/or new username)
//   delete_user  – Super Admin only

import { createClient } from "npm:@supabase/supabase-js@2";

const LOGIN_EMAIL_DOMAIN = "staff.memcouae.ae";
const PROFILE_FIELDS = ["name", "role", "site", "blocked", "hr_code", "extra"];

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const emailFor = (username: string) =>
  `${username.trim().toLowerCase()}@${LOGIN_EMAIL_DOMAIN}`;

const validUsername = (u: string) => /^[A-Za-z0-9._-]{3,40}$/.test(u);

function pickProfile(p: Record<string, unknown> | undefined) {
  const out: Record<string, unknown> = {};
  for (const k of PROFILE_FIELDS) if (p && k in p) out[k] = p[k];
  return out;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const json = (body: unknown, status = 200) =>
    new Response(JSON.stringify(body), {
      status,
      headers: { ...cors, "Content-Type": "application/json" },
    });

  const db = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    { auth: { persistSession: false, autoRefreshToken: false } },
  );

  let body: any;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Bad request" }, 400);
  }

  try {
    // ---------------- self-registration (no login needed) ----------------
    if (body.action === "register") {
      const hr = String(body.hr ?? "").trim();
      const name = String(body.name ?? "");
      const password = String(body.password ?? "");
      if (!hr) return json({ error: "HR Number is required." }, 400);
      if (password.length < 6) {
        return json({ error: "Password must be at least 6 characters." }, 400);
      }

      const { data: chk, error: chkErr } = await db.rpc("reg_check", { p_hr: hr, p_name: name });
      if (chkErr) throw chkErr;
      if (!chk?.ok) {
        return json({
          error: chk?.locked
            ? "Too many wrong attempts for this HR Number. Please contact the admin."
            : "Name does not match the HR record.",
        }, 403);
      }

      const { data: rec, error: recErr } = await db.rpc("hr_record", { p_hr: hr });
      if (recErr || !rec) return json({ error: "HR Number not found." }, 404);

      const username = "MEMCO" + hr;
      const { data: created, error: cErr } = await db.auth.admin.createUser({
        email: emailFor(username),
        password,
        email_confirm: true,
      });
      if (cErr || !created?.user) {
        const msg = /already|exists|registered/i.test(cErr?.message ?? "")
          ? "An account already exists for this HR Number. Try signing in instead."
          : (cErr?.message ?? "Could not create the account.");
        return json({ error: msg }, 409);
      }

      const { error: pErr } = await db.from("profiles").insert({
        id: created.user.id,
        username,
        hr_code: hr,
        name: rec.name,
        role: rec.is_driver ? "Driver" : "Worker",
        site: rec.site ?? "",
      });
      if (pErr) {
        await db.auth.admin.deleteUser(created.user.id);
        return json({ error: "An account already exists for this HR Number." }, 409);
      }

      await db.from("reg_attempts").delete().eq("hr_code", hr);
      return json({ ok: true, username });
    }

    // ---------------- everything below: Super Admin only ----------------
    const token = (req.headers.get("Authorization") ?? "").replace(/^Bearer\s+/i, "");
    const { data: who } = await db.auth.getUser(token);
    const callerId = who?.user?.id;
    if (!callerId) return json({ error: "Please sign in again." }, 401);

    const { data: me } = await db
      .from("profiles").select("role, blocked").eq("id", callerId).maybeSingle();
    if (!me || me.blocked || me.role !== "Super Admin") {
      return json({ error: "Only a Super Admin can do this." }, 403);
    }

    if (body.action === "create_user") {
      const username = String(body.username ?? "").trim();
      const password = String(body.password ?? "");
      if (!validUsername(username)) {
        return json({ error: "Username: 3-40 letters/numbers, . _ - only." }, 400);
      }
      if (password.length < 6) {
        return json({ error: "Password must be at least 6 characters." }, 400);
      }

      const { data: created, error: cErr } = await db.auth.admin.createUser({
        email: emailFor(username),
        password,
        email_confirm: true,
      });
      if (cErr || !created?.user) {
        const msg = /already|exists|registered/i.test(cErr?.message ?? "")
          ? "That username is already taken."
          : (cErr?.message ?? "Could not create the account.");
        return json({ error: msg }, 409);
      }

      const profile: Record<string, unknown> = {
        ...pickProfile(body.profile),
        id: created.user.id,
        username,
      };
      if (!profile.name) profile.name = username;

      const { data: row, error: pErr } = await db
        .from("profiles").insert(profile).select("app_id").single();
      if (pErr) {
        await db.auth.admin.deleteUser(created.user.id);
        return json({ error: pErr.message }, 409);
      }
      return json({ ok: true, authId: created.user.id, appId: row.app_id });
    }

    if (body.action === "update_login") {
      const authId = String(body.authId ?? "");
      const patch: Record<string, unknown> = {};
      let username: string | null = null;

      if (body.password) {
        const pw = String(body.password);
        if (pw.length < 6) return json({ error: "Password must be at least 6 characters." }, 400);
        patch.password = pw;
      }
      if (body.username) {
        username = String(body.username).trim();
        if (!validUsername(username)) {
          return json({ error: "Username: 3-40 letters/numbers, . _ - only." }, 400);
        }
        patch.email = emailFor(username);
        patch.email_confirm = true;
      }
      if (Object.keys(patch).length === 0) return json({ ok: true });

      const { error } = await db.auth.admin.updateUserById(authId, patch);
      if (error) {
        const msg = /already|exists|registered/i.test(error.message)
          ? "That username is already taken."
          : error.message;
        return json({ error: msg }, 409);
      }
      if (username) {
        const { error: uErr } = await db.from("profiles").update({ username }).eq("id", authId);
        if (uErr) return json({ error: uErr.message }, 409);
      }
      return json({ ok: true });
    }

    if (body.action === "delete_user") {
      const authId = String(body.authId ?? "");
      if (authId === callerId) return json({ error: "You cannot delete your own account." }, 400);
      const { error } = await db.auth.admin.deleteUser(authId);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (e) {
    return json({ error: (e as Error)?.message ?? String(e) }, 500);
  }
});
