-- =====================================================================
-- MEMCO Portal – Supabase security setup
-- Run ONCE in: Supabase Dashboard > SQL Editor > New query > Run
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1) User profiles (replaces the "users-v1" row that held plaintext passwords)
--    Passwords now live only in Supabase Auth (hashed).
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  app_id     bigint generated always as identity unique,
  id         uuid primary key references auth.users(id) on delete cascade,
  username   text not null,
  hr_code    text unique,
  name       text not null,
  role       text not null default 'Worker',
  site       text not null default '',
  blocked    boolean not null default false,
  extra      jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create unique index if not exists profiles_username_lower on public.profiles (lower(username));
alter table public.profiles enable row level security;

-- Wrong-name attempts during self-registration (3 strikes = locked)
create table if not exists public.reg_attempts (
  hr_code    text primary key,
  fails      int not null default 0,
  updated_at timestamptz not null default now()
);
alter table public.reg_attempts enable row level security;  -- no policies: server-side only

-- ---------------------------------------------------------------------
-- 2) Helper functions
-- ---------------------------------------------------------------------
create or replace function public.is_active_user() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and not blocked);
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and not blocked and role = 'Super Admin');
$$;

-- Finds one HR record inside the shared labor-v1 / staff-v1 JSON
create or replace function public.hr_record(p_hr text) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
           'name', r->>'name',
           'site', coalesce(r->>'site', ''),
           'is_driver', coalesce(r->>'trade', r->>'designation', '') ~* 'driver')
  from public.app_shared_state s,
       lateral jsonb_array_elements(
         case when jsonb_typeof(s.data) = 'array' then s.data else '[]'::jsonb end) r
  where s.id in ('labor-v1', 'staff-v1')
    and trim(r->>'code') = trim(p_hr)
  order by (s.id = 'labor-v1') desc
  limit 1;
$$;

-- Registration step A: returns 5 names (never says which one is correct).
-- The same HR number always gets the same 5 names, so repeating the
-- lookup does not reveal the real one.
create or replace function public.reg_lookup(p_hr text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  rec  jsonb;
  opts jsonb;
begin
  p_hr := trim(coalesce(p_hr, ''));
  if p_hr = '' then return jsonb_build_object('found', false); end if;
  rec := public.hr_record(p_hr);
  if rec is null then return jsonb_build_object('found', false); end if;
  if exists (select 1 from public.profiles where hr_code = p_hr) then
    return jsonb_build_object('found', true, 'taken', true);
  end if;
  if exists (select 1 from public.reg_attempts where hr_code = p_hr and fails >= 3) then
    return jsonb_build_object('found', true, 'locked', true);
  end if;

  select jsonb_agg(n order by md5(n || p_hr)) into opts
  from (
    select rec->>'name' as n
    union
    (select d.n
       from (select distinct r->>'name' as n
               from public.app_shared_state s,
                    lateral jsonb_array_elements(
                      case when jsonb_typeof(s.data) = 'array' then s.data else '[]'::jsonb end) r
              where s.id in ('labor-v1', 'staff-v1')
                and coalesce(r->>'name', '') <> '') d
      where d.n <> rec->>'name'
      order by md5(d.n || p_hr)
      limit 4)
  ) q;

  return jsonb_build_object('found', true, 'options', opts);
end $$;

-- Registration step B: checks the chosen name, counts wrong attempts
create or replace function public.reg_check(p_hr text, p_name text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  rec jsonb;
  f   int;
begin
  p_hr := trim(coalesce(p_hr, ''));
  select fails into f from public.reg_attempts where hr_code = p_hr;
  if coalesce(f, 0) >= 3 then
    return jsonb_build_object('ok', false, 'locked', true);
  end if;
  rec := public.hr_record(p_hr);
  if rec is not null and rec->>'name' = p_name then
    return jsonb_build_object('ok', true);
  end if;
  insert into public.reg_attempts (hr_code, fails) values (p_hr, 1)
  on conflict (hr_code) do update
    set fails = public.reg_attempts.fails + 1, updated_at = now();
  return jsonb_build_object('ok', false, 'locked', coalesce(f, 0) + 1 >= 3);
end $$;

-- Who may call what
revoke all on function public.hr_record(text) from public, anon, authenticated;
grant execute on function public.hr_record(text) to service_role;

revoke all on function public.reg_lookup(text)       from public;
revoke all on function public.reg_check(text, text)  from public;
grant execute on function public.reg_lookup(text)      to anon, authenticated;
grant execute on function public.reg_check(text, text) to anon, authenticated;

revoke all on function public.is_active_user() from public, anon;
revoke all on function public.is_admin()       from public, anon;
grant execute on function public.is_active_user() to authenticated;
grant execute on function public.is_admin()       to authenticated;

-- ---------------------------------------------------------------------
-- 3) Policies: profiles
--    Read: signed-in, non-blocked users (a blocked user sees only their
--    own row, so the app can log them out).
--    Change: Super Admin only. New accounts are created by the
--    "memco-users" Edge Function, never directly from the browser.
-- ---------------------------------------------------------------------
drop policy if exists profiles_read         on public.profiles;
drop policy if exists profiles_admin_update on public.profiles;

create policy profiles_read on public.profiles
  for select to authenticated
  using (id = auth.uid() or public.is_active_user());

create policy profiles_admin_update on public.profiles
  for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

revoke all on public.profiles, public.reg_attempts from anon;
revoke insert, delete on public.profiles from authenticated;
revoke all on public.reg_attempts from authenticated;

-- ---------------------------------------------------------------------
-- 4) Policies: app_shared_state (all app data: labor, staff, attendance,
--    overtime settings, vehicles, camps ...)
--    Removes the old "anyone with the anon key" policies.
-- ---------------------------------------------------------------------
alter table public.app_shared_state enable row level security;

do $$
declare p record;
begin
  for p in select policyname from pg_policies
           where schemaname = 'public' and tablename = 'app_shared_state'
  loop
    execute format('drop policy %I on public.app_shared_state', p.policyname);
  end loop;
end $$;

create policy shared_read on public.app_shared_state
  for select to authenticated
  using (public.is_active_user());

create policy shared_insert on public.app_shared_state
  for insert to authenticated
  with check (
    public.is_active_user()
    and (public.is_admin()
         or id not in ('users-v1', 'role-perms-matrix-v2', 'custom-roles-v1'))
  );

create policy shared_update on public.app_shared_state
  for update to authenticated
  using (
    public.is_active_user()
    and (public.is_admin()
         or id not in ('users-v1', 'role-perms-matrix-v2', 'custom-roles-v1'))
  )
  with check (
    public.is_active_user()
    and (public.is_admin()
         or id not in ('users-v1', 'role-perms-matrix-v2', 'custom-roles-v1'))
  );

create policy shared_delete on public.app_shared_state
  for delete to authenticated
  using (public.is_admin());

revoke all on public.app_shared_state from anon;

-- Remove the old row that stored every password in plain text
delete from public.app_shared_state where id = 'users-v1';

-- ---------------------------------------------------------------------
-- 5) Policies: file uploads (subcontractor-docs, vehicle-mulkiya)
-- ---------------------------------------------------------------------
do $$
declare p record;
begin
  for p in select policyname from pg_policies
           where schemaname = 'storage' and tablename = 'objects'
             and (coalesce(qual, '')       ~ '(subcontractor-docs|vehicle-mulkiya)'
               or coalesce(with_check, '') ~ '(subcontractor-docs|vehicle-mulkiya)')
  loop
    execute format('drop policy %I on storage.objects', p.policyname);
  end loop;
end $$;

create policy memco_files_select on storage.objects
  for select to authenticated
  using (bucket_id in ('subcontractor-docs', 'vehicle-mulkiya') and public.is_active_user());

create policy memco_files_insert on storage.objects
  for insert to authenticated
  with check (bucket_id in ('subcontractor-docs', 'vehicle-mulkiya') and public.is_active_user());

create policy memco_files_update on storage.objects
  for update to authenticated
  using (bucket_id in ('subcontractor-docs', 'vehicle-mulkiya') and public.is_active_user())
  with check (bucket_id in ('subcontractor-docs', 'vehicle-mulkiya') and public.is_active_user());


-- =====================================================================
-- 6) FIRST SUPER ADMIN  (run this part separately, AFTER step A below)
--
--  A. Dashboard > Authentication > Users > "Add user" > "Create new user"
--       Email:    admin@staff.memcouae.ae
--       Password: a strong password (not admin123)
--       Tick "Auto Confirm User"
--  B. Then run:
-- =====================================================================
-- insert into public.profiles (id, username, name, role)
-- select id, 'admin', 'Administrator', 'Super Admin'
-- from auth.users where email = 'admin@staff.memcouae.ae'
-- on conflict (id) do nothing;
